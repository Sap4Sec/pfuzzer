Your network has been penetrated.

All files on each host in the network have been encrypted with a strong algorithm. 

Backups were either encrypted
Shadow copies also removed, so F8 or any other methods may damage encrypted data but not recover.

We exclusively have decryption software for your situation. 
More than a year ago, world experts recognized the impossibility of deciphering by any means except the original decoder. 
No decryption software is available in the public.
Antiviruse companies, researchers, IT specialists, and no other persons cant help you decrypt the data. 

DO NOT RESET OR SHUTDOWN - files may be damaged.
DO NOT DELETE readme files. 

To confirm our honest intentions.Send 2 different random files and you will get it decrypted. 
It can be from different computers on your network to be sure that one key decrypts everything.
2 files we unlock for free

To get info (decrypt your files) contact us at 
Vulcanteam@CYBERFEAR.COM
or
vulcanteam@inboxhub.net

You will receive btc address for payment in the reply letter 

Ryuk

No system is safe